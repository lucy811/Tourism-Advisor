  
export interface Comment {
  id: string;
  travelInfoId: string;
  comment: string;
  creator: string;
  name: string;
}
