  
export interface TravelInfo {
  id: string;
  name: string;
  price: string;
  description: string;
  imagePath: string;
  creator: string;
}
